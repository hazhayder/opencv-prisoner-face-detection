package main;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AddPrisoner{
	public static Parent previous;
	public static Scene scene;
	public static Stage window;
	public static Parent root;
	public static void main(String[] args){
		try {
			root = FXMLLoader.load(AddPrisoner.class.getResource("views/AddPrisoner.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scene = new Scene(root);
		window = new Stage();
		window.setTitle("Add A Prisoner - Prisoner Face Detection System");
		window.setScene(scene);
		window.initModality(Modality.APPLICATION_MODAL);
		window.show();
		
	}
	
}
