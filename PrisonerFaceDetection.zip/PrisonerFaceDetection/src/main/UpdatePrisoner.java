package main;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class UpdatePrisoner {
	public static void main(){
		Parent root = null;
		try {
			root = FXMLLoader.load(UpdatePrisoner.class.getResource("views/UpdatePrisoner.fxml"));
		} catch (IOException e) {e.printStackTrace();}
		Scene scene = new Scene(root);
		Stage window = new Stage();
		window.setScene(scene);
		window.setTitle("Update Prisoner");
		window.initModality(Modality.APPLICATION_MODAL);
		window.show();
	}
}
