package main;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Criminal{
	String id;
	String name;
	String age;
	String imprisonmentDate;
	String punishment;
	String cellNo;
	String crime;
	String profilePic;
	boolean hasDataSet = false;
	public Criminal(){
		id=name=age=null;
		imprisonmentDate = null;
	}
	public Criminal(String id,String name,String age, int timestamp,String punishment,String cellNo,String crime){
		this.id = id;
		this.name = name;
		this.age = age;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		imprisonmentDate = sdf.format(new Date(timestamp));
		this.punishment = punishment;
		this.crime = crime;
		this.cellNo = cellNo;
		this.crime = crime;
	}
	public void setProfilePic(String pic){
		this.profilePic = pic;
	}
	public String getProfilePic(){
		return profilePic;
	}
	public void setHasDataSet(Boolean opt){
		this.hasDataSet = opt;
	}
	public boolean getHasDataSet(){
		return hasDataSet;
	}
	public String getCell(){
		return cellNo;
	}
	public String getCrime(){
		return crime;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public void setImprisonmentDate(int timestamp){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		imprisonmentDate = sdf.format(new Date(timestamp));
	}
	public String getImprisonmentDate(){
		return imprisonmentDate;
	}
	public void setPunishment(String punishment){
		this.punishment = punishment;
	}
	public String getCellNo() {
		return cellNo;
	}
	public void setCellNo(String cellNo) {
		this.cellNo = cellNo;
	}
	public void setImprisonmentDate(String imprisonmentDate) {
		int time = Integer.parseInt(imprisonmentDate);
		Date date = new Date(time * 1000L);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		this.imprisonmentDate = sdf.format(date);
	}
	public void setCrime(String crime) {
		this.crime = crime;
	}
	public String getPunishment(){
		return punishment;
	}	
}
