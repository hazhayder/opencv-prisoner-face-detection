package main.controllers;
import main.DataThread;
import main.Criminal;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.face.Face;
import org.opencv.face.LBPHFaceRecognizer;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.videoio.VideoCapture;

import com.jfoenix.controls.JFXListView;

import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * The controller for our application, where the application logic is
 * implemented. It handles the button for starting/stopping the camera and the
 * acquired video stream.
 *
 * @author <a href="mailto:luigi.derussis@polito.it">Luigi De Russis</a>
 * @author <a href="http://max-z.de">Maximilian Zuleger</a> (minor fixes)
 * @version 2.0 (2016-09-17)
 * @since 1.0 (2013-10-20)
 *
 */
public class FaceRecognizerController{
	// the FXML button
	@FXML
	private Button button;
	// the FXML image view
	@FXML
	private ImageView currentFrame;
	@FXML
	private JFXListView <Label>profileView;
	// a timer for acquiring the video stream
	private ScheduledExecutorService timer;
	// the OpenCV object that realizes the video capture
	private VideoCapture capture = new VideoCapture();
	// a flag to change the button behavior
	private boolean cameraActive = false;
	// the id of the camera to be used
	private static int cameraId = 0;
	LBPHFaceRecognizer faceRecognizer = Face.createLBPHFaceRecognizer();
	private static ArrayList<Criminal> Arr;
	public static int index;
	int currentView = -1;
	@FXML
	protected void startCamera(ActionEvent event){	
		//displayProfileWindow();
		Arr = new ArrayList<>();
		if (!this.cameraActive){
			this.capture.open(cameraId);
			faceRecognizer.load("test.xml");
			if (this.capture.isOpened()){
				this.cameraActive = true;
				//CascadeClassifier cascadeFaceClassifier = new CascadeClassifier("haarcascade_frontalface_default.xml");
				CascadeClassifier cascadeFaceClassifier = new CascadeClassifier("haarcascade_frontalface_default.xml");
				// grab a frame every 33 ms (30 frames/sec)
				Runnable frameGrabber = new Runnable() {
					@Override
					public void run(){
						Mat frame = new Mat(); 
						capture.read(frame);
						MatOfRect faces = new MatOfRect();
						cascadeFaceClassifier.detectMultiScale(frame, faces);
						for (Rect rect : faces.toArray()) {
							Mat resizedCapture = new Mat(frame,rect);
							Imgproc.cvtColor(resizedCapture, resizedCapture, Imgproc.COLOR_BGR2GRAY);
							Imgproc.resize(resizedCapture,resizedCapture , new Size(202,202));
							int x = faceRecognizer.predict_label(resizedCapture);
							System.out.println("Predicted Label: "+x+" Value in index"+index);
							DataThread thread = new DataThread(Arr,x);
							thread.run();
							String name = "No Name";
							if(index != -1 && Integer.parseInt(Arr.get(index).getId()) == x){
								name = Arr.get(index).getName();	
								if(currentView != index){
									showInListView();
								}
								
							}
							Imgproc.putText(frame, "Face: "+name, new Point(rect.x,rect.y-5), 1, 2, new Scalar(0,0,255));								
							Imgproc.rectangle(frame, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height),
									new Scalar(0, 100, 0),3);
							
						} 
						Image imageToShow = mat2Image(frame);
						updateImageView(currentFrame, imageToShow);
					}

				};
				
				this.timer = Executors.newSingleThreadScheduledExecutor();
				this.timer.scheduleAtFixedRate(frameGrabber, 0, 33, TimeUnit.MILLISECONDS);
				this.button.setText("Stop Camera");
			}
			else{
				System.err.println("Impossible to open the camera connection...");
			}
		}
		else{
			this.cameraActive = false;
			this.button.setText("Start Camera");
			this.stopAcquisition();
		}
	}
	private void showInListView() {
		currentView = index;
		profileView.getItems().clear();
		Criminal temp = Arr.get(index);
		profileView.getItems().add(new Label("Name: "+temp.getName()));
		profileView.getItems().add(new Label("Age: "+temp.getAge()));
		profileView.getItems().add(new Label("Punishment: "+temp.getPunishment()));
		profileView.getItems().add(new Label("Crime: "+temp.getCrime()));
		profileView.getItems().add(new Label("Cell No: "+temp.getCellNo()));
		profileView.getItems().add(new Label("Imprisonment Date: "+temp.getImprisonmentDate()));
		
	}
	private Mat grabFrame(){
		Mat frame = new Mat();
		if (this.capture.isOpened())
		{
			try
			{
				this.capture.read(frame);
				
				// if the frame is not empty, process it
				//if (!frame.empty())
				//{
					//Imgproc.cvtColor(frame, frame, Imgproc.COLOR_BGR2GRAY);
				//}
				
			}
			catch (Exception e)
			{
				System.err.println("Exception during the image elaboration: " + e);
			}
		}
		
		return frame;
	}
	private void stopAcquisition(){
		if (this.timer!=null && !this.timer.isShutdown())
		{
			try
			{
				// stop the timer
				this.timer.shutdown();
				this.timer.awaitTermination(33, TimeUnit.MILLISECONDS);
			}
			catch (InterruptedException e)
			{
				// log any exception
				System.err.println("Exception in stopping the frame capture, trying to release the camera now... " + e);
			}
		}
		
		if (this.capture.isOpened())
		{
			// release the camera
			this.capture.release();
		}
	}
	
	/**
	 * Update the {@link ImageView} in the JavaFX main thread
	 * 
	 * @param view
	 *            the {@link ImageView} to update
	 * @param image
	 *            the {@link Image} to show
	 */
	private void updateImageView(ImageView view, Image image)
	{
		onFXThread(view.imageProperty(), image);
	}
	public static <T> void onFXThread(final ObjectProperty<T> property, final T value)
	{
		Platform.runLater(() -> {
			property.set(value);
		});
	}
	
	/**
	 * On application close, stop the acquisition from the camera
	 */
	public void setClosed()
	{
		this.stopAcquisition();
	}
	public static Image mat2Image(Mat frame)
	{
		try
		{
			return SwingFXUtils.toFXImage(Mat2Buffer(frame), null);
		}
		catch (Exception e)
		{
			System.err.println("Cannot convert the Mat obejct: " + e);
			return null;
		}
	}
	private static BufferedImage Mat2Buffer(Mat matImage) {
	
		
		MatOfByte matOfByte = new MatOfByte();
		Imgcodecs.imencode(".jpg", matImage, matOfByte);
		byte[] byteArray = matOfByte.toArray();
		BufferedImage img = null;
		try {
			InputStream in = new ByteArrayInputStream(byteArray);
			img = ImageIO.read(in);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return img;
	}
	public void displayProfileWindow(){
		VBox vb = new VBox();
		vb.getChildren().add(profileView);
		Scene scene = new Scene(vb);
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.show();
		
	}
}