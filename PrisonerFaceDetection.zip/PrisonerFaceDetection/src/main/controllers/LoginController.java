package main.controllers;

import java.io.IOException;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import main.MainWindow;
import main.models.LoginModel;

public class LoginController {
	@FXML
	private JFXTextField txtUsername;
	@FXML
	private JFXPasswordField txtPassword;
	
	public void onLogin(){
		String username = txtUsername.getText();
		String password = txtPassword.getText();
		if(LoginModel.checkLogin(username, password)){
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource("/main/views/Welcome.fxml"));
			} catch (IOException e) {System.err.println("Exception throw"+e);}
			Scene scene = new Scene(root);
			MainWindow.window.setScene(scene);
			MainWindow.window.setTitle("Hello");
			
		}else{
			Alert alertbox = new Alert(AlertType.ERROR);
			alertbox.setHeaderText("Invalid Username or Password");
			alertbox.setContentText("Please Try Again");
			alertbox.setTitle("Login Error");
			alertbox.show();
		}
	}
}
