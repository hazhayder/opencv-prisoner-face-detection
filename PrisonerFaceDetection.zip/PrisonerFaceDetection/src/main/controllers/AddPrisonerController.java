package main.controllers;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.videoio.VideoCapture;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXSnackbar;
import com.jfoenix.controls.JFXSnackbar.SnackbarEvent;
import com.jfoenix.controls.JFXTextField;

import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import main.*;
import main.models.PrisonerModel;
public class AddPrisonerController {
	private File source = null;
	private File destination = null;
	@FXML
	JFXTextField txtName,txtAge,txtCellNo,txtCrime,txtPunishment;
	@FXML
	JFXDatePicker imrsnmntDate;
	@FXML
	JFXSnackbar notificationBar;
	@FXML
	ImageView imageView;
	//Setting Up Threading For DataSet
	private ScheduledExecutorService timer;
	private boolean startDataSet = false;
	private int userId = -1;
	@FXML
	VBox vBoxDataSet;
	@FXML
	Label lblSampleNum;
	
	public void goBack(){
		Parent root = (Parent) MainWindow.previous;
		MainWindow mw = new MainWindow();
		MainWindow.window.setScene(new Scene(root));
	}
	public void onUpload(){
		FileChooser fileChooser = new FileChooser();
		source = fileChooser.showOpenDialog(null);
		String newName = generateRandomString();
		String srcFileName = source.getName();
		String ext = srcFileName.substring(srcFileName.lastIndexOf("."));
		System.out.println("File Name: "+newName);
		System.out.println("File Extension: "+ext);
		System.out.println(newName+ext);
		destination = new File("./PrisonerPics/"+newName+ext);
		while(destination.exists()){
			newName = generateRandomString();
			destination = new File("/PrisonerPics"+newName+ext);
		}
	}
	public void saveUser(){
		System.out.println("I am called");
		if(source==null||destination==null){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Upload Profile Picture");
			alert.setHeaderText(null);
			alert.setContentText("Please Upload Profile Picture In Order to Add Prisoner");
			alert.show();
			return;
		}
		if(txtName.getText().isEmpty()){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Name cannot be empty");
			alert.show();
			return;
		}
		if(txtAge.getText().isEmpty()){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Age Cannot be empty");
			alert.show();
			return;
		}
		if(txtCellNo.getText().isEmpty()){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("You must provide a value for cell no");
			alert.show();
			return;
		}
		if(txtCrime.getText().isEmpty()){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Please provide a value for crime");
			alert.show();
			return;
		}
		if(txtPunishment.getText().isEmpty()){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.setContentText("Punishment field Cannot be empty");
			alert.show();
			return;
		}
		
		try {
			copyFile(source,destination);
			System.out.println("File Copied Successfull");
		} catch (IOException e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Error Occurred");
			alert.setHeaderText(null);
			alert.setContentText("An I/O Error has occured");
			return;
		}
		PrisonerModel pm = new PrisonerModel();
		
		userId = pm.addPrisoner(txtName.getText(), txtPunishment.getText(),txtAge.getText(),txtCrime.getText(),txtCellNo.getText(), "PrisonerPics/"+destination.getName());
		System.out.println("Outside of IF");
		if(userId != -1){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("User Added Successfull");
			alert.setHeaderText(null);
			alert.setContentText("User Added Successfull"
					+ "");
			intialiazeCv();
		}
		System.out.println("HerE");
		
		
	}
	private String generateRandomString(){
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
	}
	private static void copyFile(File sourceFile, File destFile) throws IOException {
	    if(!destFile.exists()) {
	        destFile.createNewFile();
	    }

	    FileChannel source = null;
	    FileChannel destination = null;

	    try {
	        source = new FileInputStream(sourceFile).getChannel();
	        destination = new FileOutputStream(destFile).getChannel();
	        destination.transferFrom(source, 0, source.size());
	    }
	    finally {
	        if(source != null) {
	            source.close();
	        }
	        if(destination != null) {
	            destination.close();
	        }
	    }
	}
	public void createDataSet(){
		this.startDataSet = true;
	}
	private void intialiazeCv(){
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		vBoxDataSet.setVisible(true);
		VideoCapture capture = new VideoCapture(0);
		capture.open(0);
		if(capture.isOpened()){
			CascadeClassifier cascadeFaceClassifier = new CascadeClassifier("haarcascade_frontalface_default.xml");
			Runnable frameGrabber = new Runnable() {
				int sampleNum = 0;
				@Override
				public void run()
				{
					// effectively grab and process a single frame
					
					Mat frame = new Mat(); 
					capture.read(frame);
					//Imgproc.cvtColor(frame, frame, Imgproc.COLOR_BGR2GRAY);

					MatOfRect faces = new MatOfRect();
					cascadeFaceClassifier.detectMultiScale(frame, faces);
					for (Rect rect : faces.toArray()) {
						Imgproc.putText(frame, "Face", new Point(rect.x,rect.y-5), 1, 2, new Scalar(0,0,255));								
						Imgproc.rectangle(frame, new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height),
								new Scalar(0, 100, 0),3);
						if(startDataSet){
							lblSampleNum.setText("Sample Num: "+sampleNum);
							Imgcodecs.imwrite("DataSet/User"+"."+userId+"."+sampleNum+".jpg", new Mat(frame,new Rect(rect.x,rect.y,rect.width,rect.height)));
							sampleNum++;
							if(sampleNum>=11){
								new Trainer();
								vBoxDataSet.setVisible(false);
								
								stopAcquisition();
								if(capture.isOpened()){
									capture.release();
								}
								
							}
						}
					}

					// convert and show the frame
					Image imageToShow = mat2Image(frame);
					updateImageView(imageView, imageToShow);
				}
			};
			this.timer = Executors.newSingleThreadScheduledExecutor();
			this.timer.scheduleAtFixedRate(frameGrabber, 0, 33, TimeUnit.MILLISECONDS);
		}else{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setHeaderText("Unable to open camera");
			alert.setContentText("Make sure camera is not being used by another process");
			alert.show();
		}
	}
	private void stopAcquisition(){
		if (this.timer!=null && !this.timer.isShutdown())
		{
			try
			{
				// stop the timer
				this.timer.shutdown();
				this.timer.awaitTermination(33, TimeUnit.MILLISECONDS);
			}
			catch (InterruptedException e)
			{
				// log any exception
				System.err.println("Exception in stopping the frame capture, trying to release the camera now... " + e);
			}
		}
	}
	private void updateImageView(ImageView imageView, Image imageToShow) {
		onFXThread(imageView.imageProperty(), imageToShow);
		
	}
	public static <T> void onFXThread(final ObjectProperty<T> property, final T value)
	{
		Platform.runLater(() -> {
			property.set(value);
		});
	}
	public static Image mat2Image(Mat frame)
	{
		try
		{
			return SwingFXUtils.toFXImage(Mat2Buffer(frame), null);
		}
		catch (Exception e)
		{
			System.err.println("Cannot convert the Mat obejct: " + e);
			return null;
		}
	}
	private static BufferedImage Mat2Buffer(Mat matImage) {
	
		
		MatOfByte matOfByte = new MatOfByte();
		Imgcodecs.imencode(".jpg", matImage, matOfByte);
		byte[] byteArray = matOfByte.toArray();
		BufferedImage img = null;
		try {
			InputStream in = new ByteArrayInputStream(byteArray);
			img = ImageIO.read(in);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return img;
	}
}
