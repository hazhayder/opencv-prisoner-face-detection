package main.controllers;

import java.io.IOException;

import com.jfoenix.controls.JFXTabPane;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import main.AddPrisoner;
import main.FaceRecognizer;
import main.SearchPrisoners;

public class WelcomeController{
	@FXML
	JFXTabPane tabPane;
	
	public void addPrisoner(){
		AddPrisoner.main(null);
	}
	public void startRecognizer(){
		FaceRecognizer.main(null);
	}
	public void searchPrisoner(){
		SearchPrisoners.display();
	}
}
