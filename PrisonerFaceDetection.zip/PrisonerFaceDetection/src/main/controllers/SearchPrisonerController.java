package main.controllers;

import java.io.File;
import java.io.FilenameFilter;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextField;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import main.Criminal;
import main.DB;
import main.Trainer;
import main.UpdatePrisoner;
import main.models.PrisonerModel;

public class SearchPrisonerController implements Initializable{
	@FXML
	TableView<Criminal> table;
	@FXML
	JFXTextField txtSearch;
	@FXML
	JFXListView <Label>profileView;
	@FXML
	ImageView profilePic;
	int selectedId;
	public void onSearch(){
		String txtInput = txtSearch.getText();
		if(txtSearch.getLength()>0){
			table.setItems(getCriminals(txtInput));
		}else{
			table.setItems(getCriminals(null));
		}
		
		
		
	}
	
	private ObservableList<Criminal> getCriminals(String name){
		String whereClause = " ";
		if(name!=null){
			whereClause += "where criminal_name like '%"+name+"%'";
		}
		String query = "Select * from criminals"+whereClause;
		System.out.println(query);
		ObservableList<Criminal> criminals = FXCollections.observableArrayList();
		DB.connect();
		try {
			ResultSet rs = DB.stmt.executeQuery(query);
			System.out.println(rs.getMetaData().getColumnCount());
			Criminal temp;
			int i=0;
			while(rs.next()){
				i++;
				temp = new Criminal();
				temp.setId(rs.getString("criminal_id"));
				temp.setName(rs.getString("criminal_name"));
				temp.setAge(rs.getString("criminal_age"));
				temp.setCrime(rs.getString("crime"));
				temp.setCellNo(rs.getString("cell_no"));
				temp.setImprisonmentDate(rs.getString("imprisonment_date"));
				temp.setPunishment(rs.getString("punishment"));
				temp.setProfilePic(rs.getString("profile_pic"));
				if(rs.getInt("has_dataset")==1){
					temp.setHasDataSet(true);
				}
				criminals.add(temp);
			}
			System.out.println("Rows Returned: "+i);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return criminals;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		TableColumn<Criminal, String> colID= new TableColumn<>("ID");
		colID.setCellValueFactory(new PropertyValueFactory<>("id"));
		TableColumn<Criminal, String> colName= new TableColumn<>("Name");
		colName.setCellValueFactory(new PropertyValueFactory<>("name"));
		TableColumn<Criminal, String> colAge= new TableColumn<>("Age");
		colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
		TableColumn<Criminal, String> colPunishment = new TableColumn<>("Punishment");
		colPunishment.setCellValueFactory(new PropertyValueFactory<>("punishment"));
		table.getColumns().setAll(colID,colName,colAge,colPunishment);
		table.setItems(getCriminals(null));
		table.setOnMouseClicked(e->{
			profileView.getItems().clear();
			Criminal temp = table.getSelectionModel().getSelectedItem();
			selectedId = Integer.parseInt(temp.getId());
			Image image = new Image("file:"+temp.getProfilePic());
			profilePic.setImage(image);
			profileView.getItems().add(new Label("Name: "+temp.getName()));
			profileView.getItems().add(new Label("Age: "+temp.getAge()));
			profileView.getItems().add(new Label("Punishment: "+temp.getPunishment()));
			profileView.getItems().add(new Label("Crime: "+temp.getCrime()));
			profileView.getItems().add(new Label("Cell No: "+temp.getCellNo()));
			profileView.getItems().add(new Label("Imprisonment Date: "+temp.getImprisonmentDate()));
		});
		
	}
	public void onDelete(){
		PrisonerModel pm = new PrisonerModel();
		if(pm.deletePrisoner(selectedId)){
			Alert ab = new Alert(AlertType.INFORMATION);
			ab.setHeaderText("Prisoner Deleted Successfull");
			ab.setContentText("Prisoner Deleted Successfull");
			ab.show();
			table.setItems(getCriminals(null));
			profileView.getItems().clear();
			File f = new File("DataSet/");
			FilenameFilter imgFilter = new FilenameFilter(){

				@Override
				public boolean accept(File arg0, String arg1) {
					arg1 = arg1.toLowerCase();
					return arg1.contains(Integer.toString(selectedId));
				}
			};
			File[] imagesFile = f.listFiles(imgFilter);
			for(File image:imagesFile){
				image.delete();
			}
			new Trainer();
		}else{
			Alert ab = new Alert(AlertType.ERROR);
			ab.setHeaderText("Delete Operation Failed");
			ab.setContentText("Unable to delete prisoner profile.");
			ab.show();
		}
	}
	public void onUpdate(){
		UpdateController.criminal = table.getSelectionModel().getSelectedItem();
		UpdatePrisoner.main();
	}
}
