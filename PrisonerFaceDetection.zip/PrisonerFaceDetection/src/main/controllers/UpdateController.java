package main.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTextField;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import main.Criminal;
import main.models.PrisonerModel;

public class UpdateController implements Initializable{
	static Criminal criminal;
	@FXML
	JFXTextField txtName,txtCrime,txtPunishment,txtCell;
	public void onSave(){
		String name = txtName.getText();
		String crime = txtCrime.getText();
		String punishment = txtPunishment.getText();
		String cell = txtCell.getText();
		PrisonerModel pm = new PrisonerModel();
		int result = pm.update(name, crime, punishment, cell,criminal.getId());
		if(result>0){
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setHeaderText("Successfull");
			alert.setContentText("User Updated Successfully");
			alert.show();
		}else{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setHeaderText("Error");
			alert.setContentText("An Error Occured");
			alert.show();
		}
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		txtName.setText(criminal.getName());
		txtCrime.setText(criminal.getCrime());
		txtPunishment.setText(criminal.getPunishment());
		txtCell.setText(criminal.getCellNo());
		
		
	}

}
