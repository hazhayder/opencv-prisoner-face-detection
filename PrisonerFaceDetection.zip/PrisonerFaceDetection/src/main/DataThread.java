package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import main.controllers.FaceRecognizerController;

public class DataThread implements Runnable{
	private Thread t;
	private static ArrayList<Criminal> Arr;
	private static String givenId;
	private static boolean found = false;
	public DataThread(ArrayList<Criminal>Arr,int givenId){
		this.Arr = Arr;
		this.givenId = Integer.toString(givenId);
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<Arr.size();i++){
			if(Arr.get(i).id.equals(givenId)){
				System.out.println("Index Value Changed");
				FaceRecognizerController.index = i;
				return ;
			}
		}
		System.out.println("Didn't found in Array");
		Runnable sql = new Runnable(){
			@Override
			public void run(){
				System.out.println("Fetching it from database");
				try{
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/java_proj","root","husni123");
					Statement stmt = conn.createStatement();
					String query = "select * from criminals where criminal_id = "+DataThread.givenId;
					System.out.println("Sql Query: "+query);
					ResultSet rs = stmt.executeQuery(query);
					if(!rs.next()){
						System.out.println("Given ID doesn't exist in database");
						return;
					}
					Criminal temp;
					temp = new Criminal();
					temp.setId(rs.getString("criminal_id"));
					temp.setName(rs.getString("criminal_name"));
					temp.setAge(rs.getString("criminal_age"));
					temp.setCrime(rs.getString("crime"));
					temp.setCellNo(rs.getString("cell_no"));
					temp.setImprisonmentDate(rs.getString("imprisonment_date"));
					temp.setPunishment(rs.getString("punishment"));
					Arr.add(temp);
					DataThread.found = true;
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		};
		sql.run();
		if(found){
			System.out.println("Found and Added to Array List");
			System.out.println(Arr.size());
			FaceRecognizer.index = Arr.size() - 1;
		}
	}
	
}
