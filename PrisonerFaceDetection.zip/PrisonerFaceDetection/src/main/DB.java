package main;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Connection;
public class DB {
	static Connection conn;
	public static Statement stmt;
	public static void connect(){
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/java_proj","root","husni123");
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void close(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Connection getConnection(){
		DB.connect();
		return conn;
	}
}
