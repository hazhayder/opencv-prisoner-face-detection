package main.models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import main.DB;

public class LoginModel {
	public static boolean checkLogin(String username,String password){
		Connection conn = DB.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select username,password from logins where username = ? and password = ?");
			ps.setString(1,username);
			ps.setString(2, password);
			ResultSet rslt = ps.executeQuery();
			if(rslt.next()){
				return true;
			}
		} catch (SQLException e) {}
		return false;
	}
	
}
