package main.models;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class PrisonerModel {
	private Connection conn;
	private Statement stmt;
	
	private void connect(){
		try{
			conn = DriverManager.getConnection("jdbc:mysql://localhost/java_proj","root","husni123");
			stmt = conn.createStatement();
		}catch(Exception e){
			
		}
	}
	private void close(){
		if(stmt!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public int update(String name,String crime,String punishment,String cell, String id){
		this.connect();
		int update = 0;
		String sql = "update criminals set criminal_name = ?,crime = ?,punishment = ?,cell_no = ? where criminal_id = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, crime);
			ps.setString(3, punishment);
			ps.setString(4, cell);
			ps.setString(5, id);
			update = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return update;
	}
	public int addPrisoner(String name,String punishment, String criminalAge,String crime, String cell,String profilePic){
		this.connect();
		long unixTime = System.currentTimeMillis() / 1000L;
		int userId = -1;
		try {
			String sql = "insert into criminals (criminal_name,punishment,criminal_age,crime,cell_no,imprisonment_date,profile_pic) values('"+name+"','"+punishment+"','"+criminalAge+"','"+crime+"','"+cell+"','"+unixTime+"','"+profilePic+"')";
			stmt.executeUpdate(sql,stmt.RETURN_GENERATED_KEYS);
			try(ResultSet generatedKey = stmt.getGeneratedKeys()){
				if(generatedKey.next()){
					userId = generatedKey.getInt(1);
				}
				System.out.println("User Id: "+userId);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		this.close();
		return userId;
	}
	public boolean deletePrisoner(int id){
		this.connect();
		try{
			String sql = "delete from criminals where criminal_id = "+id;
			System.out.println(sql);
			stmt.executeUpdate(sql);
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public boolean updateHasDataSet(int id){
		this.connect();
		try{
			String sql = "update criminals set has_dataset=1 where criminal_id = "+id;
			stmt.executeUpdate(sql);
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
